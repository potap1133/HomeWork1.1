﻿namespace L10_C02_class_fields_pet_SW
{
	public enum PetSex : byte
	{
		Undefined = 0,
		Male,
		Female
	}
}