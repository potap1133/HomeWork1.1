using System;

class Program
{
	static void Main()
	{
		char letter = 'A'; // declaring a single-char variable
		Console.WriteLine(letter);

		string name = "Bob"; // declaring a string variable
		Console.WriteLine(name);
	}
}
